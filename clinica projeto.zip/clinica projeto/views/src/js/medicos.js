document.addEventListener("DOMContentLoaded", () => {
  const lista = document.getElementById("listaMedicos");

  fetch("src/data/medicos.json")
    .then(response => response.json())
    .then(medicos => {
      medicos.forEach(medico => {
        const li = document.createElement("li");
        li.textContent = `${medico.nome} — CRM: ${medico.crm} — Especialidade: ${medico.especialidade}`;
        lista.appendChild(li);
      });
    })
    .catch(error => console.error("Erro ao carregar médicos:", error));
});
