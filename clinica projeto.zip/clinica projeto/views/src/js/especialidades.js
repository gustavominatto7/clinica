document.addEventListener("DOMContentLoaded", () => {
  const lista = document.getElementById("listaEspecialidades");

  fetch("src/data/especialidades.json")
    .then(response => response.json())
    .then(especialidades => {
      especialidades.forEach(esp => {
        const li = document.createElement("li");
        li.textContent = `${esp.nome} — Descrição: ${esp.descricao}`;
        lista.appendChild(li);
      });
    })
    .catch(error => console.error("Erro ao carregar especialidades:", error));
});
