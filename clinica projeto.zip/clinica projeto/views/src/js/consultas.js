document.addEventListener("DOMContentLoaded", () => {
  const lista = document.getElementById("listaConsultas");

  fetch("src/data/consultas.json")
    .then(response => response.json())
    .then(consultas => {
      consultas.forEach(consulta => {
        const li = document.createElement("li");
        li.textContent = `Paciente: ${consulta.paciente} — Médico: ${consulta.medico} — Data: ${consulta.data} — Hora: ${consulta.hora}`;
        lista.appendChild(li);
      });
    })
    .catch(error => console.error("Erro ao carregar consultas:", error));
});
