document.addEventListener("DOMContentLoaded", () => {
  const links = document.querySelectorAll("#menu a");
  const conteudo = document.getElementById("conteudo");

  // Função para carregar páginas sem recarregar o site
  async function carregarPagina(url) {
    const resposta = await fetch(url);
    const html = await resposta.text();
    conteudo.innerHTML = html;
  }

  // Adiciona eventos aos links do menu
  links.forEach(link => {
    link.addEventListener("click", e => {
      e.preventDefault();
      const url = link.getAttribute("href");
      carregarPagina(url);

      // Remove destaque antigo e adiciona ao link atual
      links.forEach(l => l.classList.remove("ativo"));
      link.classList.add("ativo");
    });
  });

  // Carrega a página inicial automaticamente
  carregarPagina("views/pages/inicio.html");
});
document.addEventListener("DOMContentLoaded", () => {
  const links = document.querySelectorAll("#menu a");
  const conteudo = document.getElementById("conteudo");

  // Função para carregar páginas sem recarregar o site
  async function carregarPagina(url) {
    const resposta = await fetch(url);
    const html = await resposta.text();
    conteudo.innerHTML = html;
  }

  // Adiciona eventos aos links do menu
  links.forEach(link => {
    link.addEventListener("click", e => {
      e.preventDefault();
      const url = link.getAttribute("href");
      carregarPagina(url);

      // Remove destaque antigo e adiciona ao link atual
      links.forEach(l => l.classList.remove("ativo"));
      link.classList.add("ativo");
    });
  });

  // Carrega a página inicial automaticamente
  carregarPagina("views/pages/inicio.html");
});
