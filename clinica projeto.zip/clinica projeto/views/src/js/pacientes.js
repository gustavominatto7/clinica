document.addEventListener("DOMContentLoaded", () => {
  const lista = document.getElementById("listaPacientes");

  fetch("src/data/pacientes.json")
    .then(response => response.json())
    .then(pacientes => {
      pacientes.forEach(paciente => {
        const li = document.createElement("li");
        li.textContent = `${paciente.nome} — ${paciente.idade} anos — ${paciente.telefone}`;
        lista.appendChild(li);
      });
    })
    .catch(error => console.error("Erro ao carregar JSON:", error));
});
